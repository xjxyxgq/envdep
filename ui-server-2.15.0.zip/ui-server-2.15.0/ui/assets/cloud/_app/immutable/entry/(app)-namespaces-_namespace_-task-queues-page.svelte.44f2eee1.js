import{S as s,b as t,a}from"../chunks/index.f7e75074.js";class o extends s{constructor(e){super(),t(this,e,null,null,a,{})}}export{o as default};
