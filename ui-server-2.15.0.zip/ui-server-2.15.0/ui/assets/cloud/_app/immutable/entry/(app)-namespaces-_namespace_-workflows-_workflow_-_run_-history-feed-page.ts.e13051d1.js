import"../chunks/index.b1f5b21f.js";import"../chunks/route-for.98bc72f1.js";import{l as t}from"../chunks/_page.e0b5990b.js";export{t as load};
