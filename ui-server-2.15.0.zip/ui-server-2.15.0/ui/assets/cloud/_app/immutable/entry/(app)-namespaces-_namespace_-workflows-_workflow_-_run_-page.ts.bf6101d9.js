import"../chunks/index.b1f5b21f.js";import{l}from"../chunks/_page.2bedfed4.js";export{l as load};
