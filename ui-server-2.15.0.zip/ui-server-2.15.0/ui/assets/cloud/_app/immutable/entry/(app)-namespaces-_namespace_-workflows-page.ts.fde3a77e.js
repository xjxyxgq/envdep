import{s as o}from"../chunks/_page.b14944b6.js";export{o as ssr};
