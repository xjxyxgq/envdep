import"../chunks/workflow-service.d607157c.js";import"../chunks/namespaces-service.ad6152d2.js";import{l as t}from"../chunks/_page.960bc7c6.js";export{t as load};
