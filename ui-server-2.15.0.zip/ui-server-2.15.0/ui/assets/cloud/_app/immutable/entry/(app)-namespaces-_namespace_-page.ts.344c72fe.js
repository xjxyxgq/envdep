import"../chunks/namespaces-service.ad6152d2.js";import{l}from"../chunks/_page.67a7cf77.js";export{l as load};
