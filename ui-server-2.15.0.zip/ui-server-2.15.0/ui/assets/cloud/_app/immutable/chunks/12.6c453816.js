import{default as t}from"../entry/(app)-import-events-page.svelte.ca85f1ab.js";export{t as component};
