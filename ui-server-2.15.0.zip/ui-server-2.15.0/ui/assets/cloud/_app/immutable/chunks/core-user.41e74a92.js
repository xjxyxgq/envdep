import{ak as r,ad as t}from"./index.f7e75074.js";import{r as o}from"./index.f72d9b22.js";const e="CoreUser",s=o({namespaceWriteDisabled:()=>!1}),c=()=>r(e)?t(e):s;export{c};
