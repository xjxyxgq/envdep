import{default as t}from"../entry/(app)-import-events-_namespace_-_workflow_-_run_-history-json-page.svelte.e05f7f78.js";export{t as component};
