import{_ as r}from"./_layout.5b4ff1ba.js";import{default as t}from"../entry/(app)-layout.svelte.6c1da3d5.js";export{t as component,r as universal};
