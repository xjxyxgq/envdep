import{_ as r}from"./_layout.dfb32b82.js";import{default as t}from"../entry/(login)-layout.svelte.a9cedbd4.js";export{t as component,r as universal};
