import{default as t}from"../entry/(app)-import-layout.svelte.d612d2af.js";export{t as component};
