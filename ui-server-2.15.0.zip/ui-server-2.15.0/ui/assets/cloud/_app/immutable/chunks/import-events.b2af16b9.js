import{w as t}from"./index.f72d9b22.js";const r=t([]),s=t([]);export{s as a,r as i};
