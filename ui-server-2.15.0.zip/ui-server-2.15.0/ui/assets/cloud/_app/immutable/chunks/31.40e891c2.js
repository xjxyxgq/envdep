import{_ as e}from"./_page.e0b5990b.js";export{e as universal};
