import{_ as e}from"./_page.6c2e7f7b.js";export{e as universal};
