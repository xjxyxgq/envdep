import{_ as e}from"./_page.06f0efb1.js";export{e as universal};
