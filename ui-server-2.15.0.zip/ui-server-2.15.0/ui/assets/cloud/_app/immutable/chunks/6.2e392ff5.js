import{default as t}from"../entry/(app)-namespaces-_namespace_-task-queues-layout.svelte.8ca116ae.js";export{t as component};
