import{_ as r}from"./_page.67a7cf77.js";import{default as t}from"../entry/(app)-namespaces-_namespace_-page.svelte.38e4c144.js";export{t as component,r as universal};
