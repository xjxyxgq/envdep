import{w as r}from"./index.f72d9b22.js";const o=r({});export{o as c};
