import{_ as r}from"./_page.c48d3a7f.js";import{default as t}from"../entry/(app)-page.svelte.3f1703af.js";export{t as component,r as universal};
