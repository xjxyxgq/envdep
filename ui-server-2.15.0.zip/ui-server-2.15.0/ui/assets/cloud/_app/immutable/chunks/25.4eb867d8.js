import{default as t}from"../entry/(app)-namespaces-_namespace_-task-queues-_queue_-page.svelte.bef7b117.js";export{t as component};
