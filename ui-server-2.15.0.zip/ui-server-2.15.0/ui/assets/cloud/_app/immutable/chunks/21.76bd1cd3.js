import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-_schedule_-page.svelte.9654def3.js";export{t as component};
