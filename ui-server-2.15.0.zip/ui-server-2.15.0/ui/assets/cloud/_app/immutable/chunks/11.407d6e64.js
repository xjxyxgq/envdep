import{_ as e}from"./_page.307bade6.js";export{e as universal};
