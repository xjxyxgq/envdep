import{default as t}from"../entry/(app)-namespaces-page.svelte.bd605694.js";export{t as component};
