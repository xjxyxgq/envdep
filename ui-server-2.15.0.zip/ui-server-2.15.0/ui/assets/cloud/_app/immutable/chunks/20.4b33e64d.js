import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-page.svelte.bff5ebf8.js";export{t as component};
