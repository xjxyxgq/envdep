import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-layout.svelte.a9cedbd4.js";export{t as component};
