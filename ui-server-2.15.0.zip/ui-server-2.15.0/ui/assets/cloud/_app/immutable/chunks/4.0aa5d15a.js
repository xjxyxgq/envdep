import{default as t}from"../entry/(app)-import-events-_namespace_-_workflow_-_run_-history-layout.svelte.7b87701b.js";export{t as component};
