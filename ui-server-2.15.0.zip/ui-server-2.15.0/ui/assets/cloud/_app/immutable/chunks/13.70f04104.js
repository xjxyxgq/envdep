import{_ as e}from"./_page.93b28aa5.js";export{e as universal};
