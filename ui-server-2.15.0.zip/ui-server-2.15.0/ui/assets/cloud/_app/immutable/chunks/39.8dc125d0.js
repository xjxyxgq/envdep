import{default as t}from"../entry/(login)-signin-page.svelte.4f33d0e9.js";export{t as component};
