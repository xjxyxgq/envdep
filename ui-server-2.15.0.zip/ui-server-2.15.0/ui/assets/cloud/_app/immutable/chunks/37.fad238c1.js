import{default as t}from"../entry/(app)-select-namespace-page.svelte.ba344462.js";export{t as component};
