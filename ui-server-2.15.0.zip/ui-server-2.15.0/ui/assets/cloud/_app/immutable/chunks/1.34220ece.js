import{default as t}from"../entry/_error.svelte.4703c575.js";export{t as component};
