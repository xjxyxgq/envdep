import{default as t}from"../entry/(app)-namespaces-_namespace_-workflows-_workflow_-_run_-workers-page.svelte.07b446aa.js";export{t as component};
