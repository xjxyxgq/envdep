const e=!1,s=Object.freeze(Object.defineProperty({__proto__:null,ssr:!1},Symbol.toStringTag,{value:"Module"}));export{s as _,e as s};
