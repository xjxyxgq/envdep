import{h as t}from"./has.8da86d13.js";function e(s){return s?t(s,"statusCode","statusText","response"):!1}export{e as i};
