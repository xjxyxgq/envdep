import{w as s}from"./index.f72d9b22.js";import{p as a}from"./persist-store.98959e70.js";const r=a("lastNamespace","default",!0),o=s([]);export{r as l,o as n};
