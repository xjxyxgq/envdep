import{H as t,R as n}from"./control.e7f5239e.js";function c(r,e){return new t(r,e)}function i(r,e){return new n(r,e)}new TextEncoder;export{c as e,i as r};
