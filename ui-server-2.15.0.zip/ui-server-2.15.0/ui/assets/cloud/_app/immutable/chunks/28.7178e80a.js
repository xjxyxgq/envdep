import{_ as r}from"./_page.2bedfed4.js";import{default as t}from"../entry/(app)-namespaces-_namespace_-workflows-_workflow_-_run_-page.svelte.44f2eee1.js";export{t as component,r as universal};
