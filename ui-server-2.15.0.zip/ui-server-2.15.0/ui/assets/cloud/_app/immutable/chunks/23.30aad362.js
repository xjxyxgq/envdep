import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-create-page.svelte.d27279a2.js";export{t as component};
