import{_ as r}from"./_layout.e4a84b88.js";import{default as t}from"../entry/layout.svelte.a9cedbd4.js";export{t as component,r as universal};
