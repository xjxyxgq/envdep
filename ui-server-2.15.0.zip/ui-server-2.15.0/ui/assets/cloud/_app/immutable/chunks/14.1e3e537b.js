import{default as t}from"../entry/(app)-import-events-_namespace_-_workflow_-_run_-history-compact-page.svelte.037dce7e.js";export{t as component};
