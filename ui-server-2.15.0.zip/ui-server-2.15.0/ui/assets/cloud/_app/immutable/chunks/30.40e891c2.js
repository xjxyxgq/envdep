import{_ as e}from"./_page.96a0b9b6.js";export{e as universal};
