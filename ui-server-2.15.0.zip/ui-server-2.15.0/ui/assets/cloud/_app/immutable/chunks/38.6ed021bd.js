import{default as t}from"../entry/(login)-login-page.svelte.4f33d0e9.js";export{t as component};
