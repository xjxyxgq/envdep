import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-_schedule_-edit-page.svelte.38cf9c22.js";export{t as component};
