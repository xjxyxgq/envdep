import{default as t}from"../entry/(app)-namespaces-_namespace_-task-queues-page.svelte.44f2eee1.js";export{t as component};
