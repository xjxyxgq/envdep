import{_ as r}from"./_page.960bc7c6.js";import{default as t}from"../entry/(app)-namespaces-_namespace_-archival-page.svelte.13689642.js";export{t as component,r as universal};
