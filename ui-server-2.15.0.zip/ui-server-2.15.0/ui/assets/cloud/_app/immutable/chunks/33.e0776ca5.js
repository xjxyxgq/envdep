import{default as t}from"../entry/(app)-namespaces-_namespace_-workflows-_workflow_-_run_-pending-activities-page.svelte.83c75386.js";export{t as component};
