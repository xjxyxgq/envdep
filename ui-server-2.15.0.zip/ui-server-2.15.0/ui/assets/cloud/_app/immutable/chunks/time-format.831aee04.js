import{p as s}from"./persist-store.98959e70.js";const o=s("timeFormat","UTC"),m=t=>{o.set(t)};export{m as s,o as t};
