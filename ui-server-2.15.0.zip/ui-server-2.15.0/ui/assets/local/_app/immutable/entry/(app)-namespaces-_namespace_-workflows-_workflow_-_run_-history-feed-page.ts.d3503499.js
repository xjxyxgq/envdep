import"../chunks/index.b1f5b21f.js";import"../chunks/route-for.3fd20d33.js";import{l as t}from"../chunks/_page.043f2e37.js";export{t as load};
