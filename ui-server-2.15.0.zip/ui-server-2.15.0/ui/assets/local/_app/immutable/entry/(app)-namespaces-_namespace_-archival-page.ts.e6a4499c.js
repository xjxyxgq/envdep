import"../chunks/workflow-service.39104f93.js";import"../chunks/namespaces-service.8c74ed2d.js";import{l as t}from"../chunks/_page.8da7c887.js";export{t as load};
