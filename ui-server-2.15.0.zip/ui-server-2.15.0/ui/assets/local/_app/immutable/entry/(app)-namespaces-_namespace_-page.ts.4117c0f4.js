import"../chunks/namespaces-service.8c74ed2d.js";import{l}from"../chunks/_page.ba3372a7.js";export{l as load};
