import{default as t}from"../entry/(login)-signin-page.svelte.c9e96638.js";export{t as component};
