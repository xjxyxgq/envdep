import{_ as r}from"./_page.edc5f717.js";import{default as t}from"../entry/(app)-page.svelte.9afa17c2.js";export{t as component,r as universal};
