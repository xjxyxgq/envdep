import{_ as e}from"./_page.93b6b0fe.js";export{e as universal};
