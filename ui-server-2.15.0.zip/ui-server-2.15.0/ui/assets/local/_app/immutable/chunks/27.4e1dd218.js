import{_ as e}from"./_page.470b5ddc.js";export{e as universal};
