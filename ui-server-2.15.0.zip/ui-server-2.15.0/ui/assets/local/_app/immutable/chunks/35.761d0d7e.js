import{default as t}from"../entry/(app)-namespaces-_namespace_-workflows-_workflow_-_run_-stack-trace-page.svelte.3d804daa.js";export{t as component};
