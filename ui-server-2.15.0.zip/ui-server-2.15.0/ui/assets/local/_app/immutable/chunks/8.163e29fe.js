import{_ as r}from"./_layout.7e48a715.js";import{default as t}from"../entry/(login)-layout.svelte.a9cedbd4.js";export{t as component,r as universal};
