import{default as t}from"../entry/(app)-import-events-page.svelte.1da1c5f9.js";export{t as component};
