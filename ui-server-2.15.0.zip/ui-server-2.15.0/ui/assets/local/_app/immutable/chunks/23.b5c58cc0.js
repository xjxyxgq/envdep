import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-create-page.svelte.f438b4b4.js";export{t as component};
