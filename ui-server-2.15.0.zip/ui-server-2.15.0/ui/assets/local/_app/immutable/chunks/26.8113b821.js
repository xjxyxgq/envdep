import{_ as r}from"./_page.b14944b6.js";import{default as t}from"../entry/(app)-namespaces-_namespace_-workflows-page.svelte.7f97db74.js";export{t as component,r as universal};
