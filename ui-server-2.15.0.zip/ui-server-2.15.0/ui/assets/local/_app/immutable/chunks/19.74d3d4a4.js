import{_ as r}from"./_page.8da7c887.js";import{default as t}from"../entry/(app)-namespaces-_namespace_-archival-page.svelte.c994aba5.js";export{t as component,r as universal};
