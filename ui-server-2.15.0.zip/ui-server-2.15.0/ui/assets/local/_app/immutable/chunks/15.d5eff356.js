import{default as t}from"../entry/(app)-import-events-_namespace_-_workflow_-_run_-history-feed-page.svelte.3b813b45.js";export{t as component};
