import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-_schedule_-edit-page.svelte.f08a3441.js";export{t as component};
