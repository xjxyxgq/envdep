import{default as t}from"../entry/(app)-import-events-_namespace_-_workflow_-_run_-history-compact-page.svelte.be6e1d45.js";export{t as component};
