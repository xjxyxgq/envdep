import{default as t}from"../entry/(app)-namespaces-_namespace_-schedules-page.svelte.4b669936.js";export{t as component};
