import{_ as r}from"./_page.ba3372a7.js";import{default as t}from"../entry/(app)-namespaces-_namespace_-page.svelte.d94e7444.js";export{t as component,r as universal};
