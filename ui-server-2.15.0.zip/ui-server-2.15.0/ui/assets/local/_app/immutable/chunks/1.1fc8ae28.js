import{default as t}from"../entry/_error.svelte.7ba66ac0.js";export{t as component};
