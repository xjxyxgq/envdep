import{default as t}from"../entry/(app)-import-layout.svelte.2fd4064a.js";export{t as component};
