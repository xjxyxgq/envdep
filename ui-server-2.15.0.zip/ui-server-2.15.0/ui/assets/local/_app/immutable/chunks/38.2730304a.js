import{default as t}from"../entry/(login)-login-page.svelte.c9e96638.js";export{t as component};
