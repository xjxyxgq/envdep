import{default as t}from"../entry/(app)-select-namespace-page.svelte.7f0a3175.js";export{t as component};
