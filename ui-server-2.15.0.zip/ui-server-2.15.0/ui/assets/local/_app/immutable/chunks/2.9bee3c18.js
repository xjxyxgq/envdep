import{_ as r}from"./_layout.f02a8beb.js";import{default as t}from"../entry/(app)-layout.svelte.b4ac4e02.js";export{t as component,r as universal};
