import{_ as e}from"./_page.043f2e37.js";export{e as universal};
