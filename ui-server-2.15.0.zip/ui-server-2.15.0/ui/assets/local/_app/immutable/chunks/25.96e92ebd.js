import{default as t}from"../entry/(app)-namespaces-_namespace_-task-queues-_queue_-page.svelte.2b361840.js";export{t as component};
