import{default as t}from"../entry/(app)-namespaces-_namespace_-workflows-_workflow_-_run_-workers-page.svelte.4f968811.js";export{t as component};
