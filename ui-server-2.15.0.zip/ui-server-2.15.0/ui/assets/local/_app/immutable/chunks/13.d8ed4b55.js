import{_ as e}from"./_page.d4cc8f16.js";export{e as universal};
