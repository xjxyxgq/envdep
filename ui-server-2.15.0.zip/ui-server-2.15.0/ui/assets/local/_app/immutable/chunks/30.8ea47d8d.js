import{_ as e}from"./_page.0332a3b4.js";export{e as universal};
