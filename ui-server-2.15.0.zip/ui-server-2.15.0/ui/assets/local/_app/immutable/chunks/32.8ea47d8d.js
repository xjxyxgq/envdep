import{_ as e}from"./_page.b91d920a.js";export{e as universal};
