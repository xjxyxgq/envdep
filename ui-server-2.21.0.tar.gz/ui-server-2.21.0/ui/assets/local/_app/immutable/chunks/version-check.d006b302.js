const n=(r,t)=>{if(!r||!t)return!1;const[e,s,p]=r.split(".").map(Number),[a,i,m]=t.split(".").map(Number);return e!==a?e>a:s!==i?s>i:p>m};export{n as i};
