import{w as t}from"./singletons.61fcbd4c.js";const r=t([]),s=t([]);export{s as a,r as i};
