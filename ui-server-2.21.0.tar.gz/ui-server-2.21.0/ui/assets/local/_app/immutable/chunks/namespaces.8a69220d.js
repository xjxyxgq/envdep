import{w as s}from"./singletons.61fcbd4c.js";import{p as a}from"./persist-store.57987307.js";const r=a("lastNamespace","default",!0),o=s([]);export{r as l,o as n};
