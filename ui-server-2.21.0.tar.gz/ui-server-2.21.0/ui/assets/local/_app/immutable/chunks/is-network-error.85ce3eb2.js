import{h as t}from"./has.0120f47d.js";function e(s){return s?t(s,"statusCode","statusText","response"):!1}export{e as i};
