import{H as t,R as n}from"./control.f5b05b5f.js";function i(r,e){return new t(r,e)}function c(r,e){return new n(r,e.toString())}new TextEncoder;export{i as e,c as r};
