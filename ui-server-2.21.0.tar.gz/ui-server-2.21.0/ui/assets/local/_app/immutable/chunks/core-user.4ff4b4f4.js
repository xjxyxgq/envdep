import{r}from"./singletons.61fcbd4c.js";import{al as t,af as o}from"./index.9b814669.js";const e="CoreUser",s=r({namespaceWriteDisabled:()=>!1}),c=()=>t(e)?o(e):s;export{c};
