import{h as t}from"./singletons.61fcbd4c.js";const o=t("goto"),e=t("after_navigate");export{e as a,o as g};
