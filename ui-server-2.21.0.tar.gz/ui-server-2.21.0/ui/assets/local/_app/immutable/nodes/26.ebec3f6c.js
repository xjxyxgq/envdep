import{S as s,b as t,a as n}from"../chunks/index.9b814669.js";class l extends s{constructor(e){super(),t(this,e,null,null,n,{})}}export{l as component};
